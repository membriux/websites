

document.write('\
\
<nav class="navbar navbar-static-bottom navbar-default" >\
    <div class="container-fluid">\
      <div class="navbar-text pull-left">\
        <p class="copyright text-center"> &copy; 2016 Vida Nueva</p>\
      </div>\
      <div class="navbar-text pull-right">\
        <p class="horario-center">\
        <a class="footer-widget" href="https://www.facebook.com/Vida.Nueva.FF">\
          <img class="footer-widget"title="Facebook" alt="Facebook" src="VN/footer/facebook.png" width="35" height="35" />\
        </a>\
        <a class="footer-widget" href="https://soundcloud.com/tuvidanueva">\
          <img class="footer-widget" src="VN/footer/soundcloud.png" alt="SoundCloud">\
        </a>\
        <a class="footer-widget" href="https://www.youtube.com/channel/UC_aDAeNyjmPONJC0Vfxlsgg">\
          <img class="footer-widget" title="YouTube" alt="YouTube" src="VN/footer/youtube.png">\
        </a>\
        </p>\
      </div>\
    </div>\
  </div>\
</nav>\
\
');
