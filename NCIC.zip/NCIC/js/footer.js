document.write('\
<!-- Footer\
============================================= -->\
<footer id="footer" class="dark">\
\
  <div class="container">\
\
    <!-- Footer Widgets\
    ============================================= -->\
    <div class="footer-widgets-wrap clearfix">\
\
        <div class="widget clear-bottommargin-sm clearfix">\
\
          <div class="row">\
\
            <div class="col-md-6 col-sm-6 bottommargin-sm">\
              <div class="footer-big-contacts">\
                <span>Call Us:</span>\
                <a href="tel:+(510) 635-4371">(510) 635-4371</a>\
              </div>\
            </div>\
\
            <div class="col-md-6 col-sm-6 bottommargin-sm">\
              <div class="footer-big-contacts">\
                <span>Send an Email:</span>\
                <a href="mailto:ncic5354@sbcglobal.net?Subject=" target="_top">ncic5354@sbcglobal.net\
              </div>\
            </div>\
\
          </div>\
\
        </div>\
\
        <div class="widget subscribe-widget clearfix">\
          <div class="row">\
\
            <div class="col-md-4 col-sm-4 clearfix bottommargin-sm">\
              <a href="https://www.facebook.com/Northern-California-Institute-of-Cosmetology-New-588165801386123/" class="social-icon si-dark si-colored si-facebook nobottommargin" style="margin-right: 10px;">\
                <i class="icon-facebook"></i>\
                <i class="icon-facebook"></i>\
              </a>\
              <a href="https://www.facebook.com/Northern-California-Institute-of-Cosmetology-New-588165801386123/"><small style="display: block; margin-top: 3px;"><strong>Like us</strong><br>on Facebook</small></a>\
            </div>\
            <div class="col-md-4 col-sm-4 clearfix bottommargin-sm">\
              <a href="https://twitter.com/ncic510" class="social-icon si-dark si-colored si-twitter nobottommargin" style="margin-right: 10px;">\
                <i class="icon-twitter"></i>\
                <i class="icon-twitter"></i>\
              </a>\
              <a href="https://twitter.com/ncic510"><small style="display: block; margin-top: 3px;"><strong>Follow us</strong><br>on Twitter</small></a>\
            </div>\
            <div class="col-md-4 col-sm-4 clearfix">\
              <a href="https://www.instagram.com/ncicsuccess/?hl=en" class="social-icon si-dark si-colored si-instagram nobottommargin" style="margin-right: 10px;">\
                <i class="icon-instagram2"></i>\
                <i class="icon-instagram2"></i>\
              </a>\
              <a href="https://www.instagram.com/ncicsuccess/?hl=en"><small style="display: block; margin-top: 3px;"><strong>Follow us</strong><br>on Instagram</small></a>\
            </div>\
\
          </div>\
        </div>\
\
    </div><!-- .footer-widgets-wrap end -->\
\
  </div>\
\
  <!-- Copyrights\
  ============================================= -->\
  <div id="copyrights">\
\
    <div class="container clearfix">\
\
      <div class="col_half">\
        Copyrights &copy; 2016 All Rights Reserved by Northern California Institute of Cosmetology<br>\
      </div>\
\
      <div class="col_half col_last tright">\
        <div class="copyrights-menu copyright-links clearfix">\
          <a href="index.html">Home</a>/<a href="about.html">About Us</a>/<a href="contact.html">Contact</a>/<a href="credits.html">Photo Credits</a>\
        </div>\
      </div>\
\
    </div>\
\
  </div><!-- #copyrights end -->\
\
</footer><!-- #footer end -->\
\
');
